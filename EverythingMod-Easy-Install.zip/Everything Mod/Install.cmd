@echo off
rem Double-click me. Runs install.ps1 from this folder.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
