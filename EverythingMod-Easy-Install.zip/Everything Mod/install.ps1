# Installs Fabric + the Everything Mod into its own Minecraft profile ("Everything Mod").
# Uses a separate game folder so the player's normal worlds and mods are never touched.
$ErrorActionPreference = 'Stop'
$MC      = '26.2'
$LOADER  = '0.19.5'   # EM builds on it; Distant Horizons 3.3 needs >=0.19.5
$id      = "fabric-loader-$LOADER-$MC"
$root    = Join-Path $env:APPDATA '.minecraft'
$game    = Join-Path $env:APPDATA '.minecraft-everything'
$here    = Split-Path -Parent $MyInvocation.MyCommand.Path

function Fail($msg) { Write-Host ""; Write-Host "PROBLEM: $msg" -ForegroundColor Red; exit 1 }

Write-Host "Everything Mod installer" -ForegroundColor Cyan

$jar = Get-ChildItem -Path $here -Filter 'EverythingMod-*.jar' | Sort-Object Name | Select-Object -Last 1
if (-not $jar) { Fail "The mod file is missing. Right-click the zip, choose 'Extract All', then run Install from the extracted folder." }

$profileFiles = @('launcher_profiles.json', 'launcher_profiles_microsoft_store.json') |
    ForEach-Object { Join-Path $root $_ } | Where-Object { Test-Path $_ }
if (-not $profileFiles) { Fail "Minecraft Launcher not found. Install it, sign in, start normal Minecraft once, close it, then run Install again." }

if (Get-Process -Name 'javaw','Minecraft*' -ErrorAction SilentlyContinue) {
    Fail "Minecraft or its launcher is open. Close it, then run Install again."
}

# 1. Fabric loader (the launcher downloads Minecraft and Java itself on first start)
Write-Host "1/3 Getting Fabric..."
$verDir = Join-Path $root "versions\$id"
New-Item -ItemType Directory -Force -Path $verDir | Out-Null
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing "https://meta.fabricmc.net/v2/versions/loader/$MC/$LOADER/profile/json" -OutFile (Join-Path $verDir "$id.json")
} catch { Fail "Could not download Fabric. Check the internet connection and try again." }

# 2. Mod + safe starting settings
Write-Host "2/3 Copying the Everything Mod..."
$mods = Join-Path $game 'mods'
New-Item -ItemType Directory -Force -Path $mods | Out-Null
Get-ChildItem $mods -Filter 'EverythingMod-*.jar' | Where-Object Name -ne $jar.Name | Remove-Item -Force
# keep only the Everything Mod plus Sodium, Iris, Distant Horizons and JourneyMap; other mods are moved aside, not deleted
$keep = '^(EverythingMod-|sodium-fabric-|iris-|DistantHorizons-|journeymap-)'
$extra = Get-ChildItem $mods -Filter '*.jar' | Where-Object { $_.Name -notmatch $keep }
if ($extra) {
    $aside = Join-Path $game 'mods-removed'
    New-Item -ItemType Directory -Force -Path $aside | Out-Null
    $extra | Move-Item -Destination $aside -Force
    Write-Host "   Moved $($extra.Count) other mod(s) to $aside"
}
Copy-Item $jar.FullName $mods -Force
# copy resource packs and shader packs from normal Minecraft (never overwrites ones already here)
foreach ($d in 'resourcepacks', 'shaderpacks') {
    $from = Join-Path $root $d
    if (-not (Test-Path $from)) { continue }
    $to = Join-Path $game $d
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    $new = Get-ChildItem $from | Where-Object { -not (Test-Path (Join-Path $to $_.Name)) }
    $new | Copy-Item -Destination $to -Recurse
    if ($new) { Write-Host "   Copied $(@($new).Count) item(s) from your $d" }
}
# no options.txt: the mod rates the PC on first start and picks settings to match

# 3. Launcher profile
Write-Host "3/3 Adding the 'Everything Mod' profile to the launcher..."
# memory for the game: half the PC's RAM, between 2 and 16 GB (never more than half, so a small PC stays usable)
$ramGb = [math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$heap  = [math]::Max(2, [math]::Min(16, [math]::Floor($ramGb / 2)))
$now = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
foreach ($f in $profileFiles) {
    Copy-Item $f "$f.before-everything-mod" -Force
    $json = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $json.profiles) { $json | Add-Member profiles ([pscustomobject]@{}) -Force }
    # updating: keep the memory size the player set in the launcher
    $mem = "${heap}G"
    $old = $json.profiles.'everything-mod'
    if ($old -and $old.javaArgs -match '-Xmx(\S+)') { $mem = $Matches[1] }
    $p = [pscustomobject]@{
        name = 'Everything Mod'; type = 'custom'; lastVersionId = $id; gameDir = $game
        icon = 'Grass'; created = $now; lastUsed = $now
        # the launcher's own default arguments, with the memory size changed
        javaArgs = "-Xmx$mem -XX:+UnlockExperimentalVMOptions -XX:+UseG1GC -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M"
    }
    $json.profiles | Add-Member 'everything-mod' $p -Force
    # no BOM: the launcher expects plain UTF-8
    [IO.File]::WriteAllText($f, ($json | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding $false))
}

Write-Host ""
Write-Host "Done! Open the Minecraft Launcher, pick 'Everything Mod' next to the Play button, and press Play." -ForegroundColor Green
